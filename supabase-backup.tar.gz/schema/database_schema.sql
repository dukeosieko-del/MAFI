


SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;


CREATE EXTENSION IF NOT EXISTS "pg_cron" WITH SCHEMA "pg_catalog";






COMMENT ON SCHEMA "public" IS 'standard public schema';



CREATE EXTENSION IF NOT EXISTS "pg_stat_statements" WITH SCHEMA "extensions";






CREATE EXTENSION IF NOT EXISTS "pgcrypto" WITH SCHEMA "extensions";






CREATE EXTENSION IF NOT EXISTS "supabase_vault" WITH SCHEMA "vault";






CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA "extensions";






CREATE OR REPLACE FUNCTION "public"."credit_wallet"("p_user_id" "uuid", "p_amount" numeric) RETURNS TABLE("new_balance" numeric)
    LANGUAGE "plpgsql"
    AS $$
BEGIN
  IF p_amount <= 0 THEN
    RETURN QUERY SELECT COALESCE(wallet_balance, 0) FROM profiles WHERE id = p_user_id;
    RETURN;
  END IF;

  UPDATE profiles
  SET wallet_balance = wallet_balance + p_amount
  WHERE id = p_user_id;

  IF NOT FOUND THEN
    RETURN QUERY SELECT 0::DECIMAL;
  ELSE
    RETURN QUERY SELECT wallet_balance FROM profiles WHERE id = p_user_id;
  END IF;
END;
$$;


ALTER FUNCTION "public"."credit_wallet"("p_user_id" "uuid", "p_amount" numeric) OWNER TO "postgres";


COMMENT ON FUNCTION "public"."credit_wallet"("p_user_id" "uuid", "p_amount" numeric) IS 'Atomically credits a user wallet. Use for M-Pesa top-ups.';



CREATE OR REPLACE FUNCTION "public"."debit_wallet"("p_user_id" "uuid", "p_amount" numeric) RETURNS TABLE("new_balance" numeric, "success" boolean)
    LANGUAGE "plpgsql"
    AS $$
BEGIN
  IF p_amount < 0 THEN
    RETURN QUERY SELECT wallet_balance, FALSE FROM profiles WHERE id = p_user_id;
    RETURN;
  END IF;

  UPDATE profiles
  SET wallet_balance = wallet_balance - p_amount
  WHERE id = p_user_id AND wallet_balance >= p_amount;

  IF NOT FOUND THEN
    RETURN QUERY SELECT wallet_balance, FALSE FROM profiles WHERE id = p_user_id;
  ELSE
    RETURN QUERY SELECT wallet_balance, TRUE FROM profiles WHERE id = p_user_id;
  END IF;
END;
$$;


ALTER FUNCTION "public"."debit_wallet"("p_user_id" "uuid", "p_amount" numeric) OWNER TO "postgres";


COMMENT ON FUNCTION "public"."debit_wallet"("p_user_id" "uuid", "p_amount" numeric) IS 'Atomically debits a user wallet only if sufficient balance exists. Returns success flag.';



CREATE OR REPLACE FUNCTION "public"."generate_order_id"() RETURNS "trigger"
    LANGUAGE "plpgsql" SECURITY DEFINER
    AS $$
BEGIN
  IF NEW.order_id IS NULL OR NEW.order_id = '' THEN
    NEW.order_id = 'ORD-' || upper(substr(replace(NEW.id::text, '-', ''), 1, 8));
  END IF;
  RETURN NEW;
END;
$$;


ALTER FUNCTION "public"."generate_order_id"() OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."get_anonymous_order"("p_order_id" "uuid", "p_phone" "text") RETURNS TABLE("id" "uuid", "order_id" "text", "service_name" "text", "link" "text", "quantity" integer, "amount" numeric, "payment_status" "text", "fulfillment_status" "text", "provider_order_id" "text", "status" "text", "phone_number" "text", "created_at" timestamp with time zone, "provider_status" "text")
    LANGUAGE "plpgsql" SECURITY DEFINER
    AS $$
BEGIN
  RETURN QUERY
  SELECT
    o.id, o.order_id, o.service_name, o.link, o.quantity, o.amount,
    o.payment_status, o.fulfillment_status, o.provider_order_id,
    o.status, o.phone_number, o.created_at, o.provider_status
  FROM public.orders o
  WHERE o.id = p_order_id
    AND (o.phone_number = p_phone OR o.user_id = auth.uid());
END;
$$;


ALTER FUNCTION "public"."get_anonymous_order"("p_order_id" "uuid", "p_phone" "text") OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."handle_new_user"() RETURNS "trigger"
    LANGUAGE "plpgsql" SECURITY DEFINER
    AS $$
BEGIN
  INSERT INTO public.profiles (id, email, full_name)
  VALUES (NEW.id, NEW.email, NEW.raw_user_meta_data->>'full_name');
  RETURN NEW;
END;
$$;


ALTER FUNCTION "public"."handle_new_user"() OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."increment_blog_view"("p_post_id" "uuid") RETURNS "void"
    LANGUAGE "plpgsql"
    AS $$
BEGIN
  UPDATE public.blog_posts
  SET view_count = view_count + 1
  WHERE id = p_post_id;
END;
$$;


ALTER FUNCTION "public"."increment_blog_view"("p_post_id" "uuid") OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."rls_auto_enable"() RETURNS "event_trigger"
    LANGUAGE "plpgsql" SECURITY DEFINER
    SET "search_path" TO 'pg_catalog'
    AS $$
DECLARE
  cmd record;
BEGIN
  FOR cmd IN
    SELECT *
    FROM pg_event_trigger_ddl_commands()
    WHERE command_tag IN ('CREATE TABLE', 'CREATE TABLE AS', 'SELECT INTO')
      AND object_type IN ('table','partitioned table')
  LOOP
     IF cmd.schema_name IS NOT NULL AND cmd.schema_name IN ('public') AND cmd.schema_name NOT IN ('pg_catalog','information_schema') AND cmd.schema_name NOT LIKE 'pg_toast%' AND cmd.schema_name NOT LIKE 'pg_temp%' THEN
      BEGIN
        EXECUTE format('alter table if exists %s enable row level security', cmd.object_identity);
        RAISE LOG 'rls_auto_enable: enabled RLS on %', cmd.object_identity;
      EXCEPTION
        WHEN OTHERS THEN
          RAISE LOG 'rls_auto_enable: failed to enable RLS on %', cmd.object_identity;
      END;
     ELSE
        RAISE LOG 'rls_auto_enable: skip % (either system schema or not in enforced list: %.)', cmd.object_identity, cmd.schema_name;
     END IF;
  END LOOP;
END;
$$;


ALTER FUNCTION "public"."rls_auto_enable"() OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."sync_email_verified"() RETURNS "trigger"
    LANGUAGE "plpgsql" SECURITY DEFINER
    AS $$
BEGIN
  IF NEW.email_confirmed_at IS NOT NULL AND OLD.email_confirmed_at IS NULL THEN
    UPDATE public.profiles
    SET email_verified = TRUE
    WHERE id = NEW.id;
  END IF;
  RETURN NEW;
END;
$$;


ALTER FUNCTION "public"."sync_email_verified"() OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."update_janjez_service_timestamp"() RETURNS "trigger"
    LANGUAGE "plpgsql" SECURITY DEFINER
    AS $$
BEGIN
  NEW.updated_at = TIMEZONE('utc'::text, NOW());
  RETURN NEW;
END;
$$;


ALTER FUNCTION "public"."update_janjez_service_timestamp"() OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."update_order_timestamp"() RETURNS "trigger"
    LANGUAGE "plpgsql" SECURITY DEFINER
    AS $$
BEGIN
  NEW.updated_at = TIMEZONE('utc'::text, NOW());
  RETURN NEW;
END;
$$;


ALTER FUNCTION "public"."update_order_timestamp"() OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."update_profile_timestamp"() RETURNS "trigger"
    LANGUAGE "plpgsql" SECURITY DEFINER
    AS $$
BEGIN
  NEW.updated_at = TIMEZONE('utc'::text, NOW());
  RETURN NEW;
END;
$$;


ALTER FUNCTION "public"."update_profile_timestamp"() OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."update_service_mapping_timestamp"() RETURNS "trigger"
    LANGUAGE "plpgsql" SECURITY DEFINER
    AS $$
BEGIN
  NEW.updated_at = TIMEZONE('utc'::text, NOW());
  RETURN NEW;
END;
$$;


ALTER FUNCTION "public"."update_service_mapping_timestamp"() OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."update_transaction_timestamp"() RETURNS "trigger"
    LANGUAGE "plpgsql" SECURITY DEFINER
    AS $$
BEGIN
  NEW.updated_at = TIMEZONE('utc'::text, NOW());  RETURN NEW;
END;
$$;


ALTER FUNCTION "public"."update_transaction_timestamp"() OWNER TO "postgres";

SET default_tablespace = '';

SET default_table_access_method = "heap";


CREATE TABLE IF NOT EXISTS "public"."admin_activity_logs" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "actor_id" "uuid",
    "actor_email" "text",
    "action" "text" NOT NULL,
    "target_type" "text",
    "target_id" "text",
    "details" "jsonb",
    "ip_address" "text",
    "user_agent" "text",
    "created_at" timestamp with time zone DEFAULT "timezone"('utc'::"text", "now"()) NOT NULL
);


ALTER TABLE "public"."admin_activity_logs" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."affiliate_earnings" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "referrer_id" "uuid" NOT NULL,
    "order_id" "uuid",
    "amount" numeric(10,2) NOT NULL,
    "status" "text" DEFAULT 'pending'::"text" NOT NULL,
    "created_at" timestamp with time zone DEFAULT "timezone"('utc'::"text", "now"()) NOT NULL,
    CONSTRAINT "affiliate_earnings_amount_check" CHECK (("amount" >= (0)::numeric)),
    CONSTRAINT "affiliate_earnings_status_check" CHECK (("status" = ANY (ARRAY['pending'::"text", 'paid'::"text", 'cancelled'::"text"])))
);


ALTER TABLE "public"."affiliate_earnings" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."affiliate_referrals" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "referrer_id" "uuid" NOT NULL,
    "referee_id" "uuid",
    "referee_email" "text",
    "code" "text" NOT NULL,
    "status" "text" DEFAULT 'pending'::"text" NOT NULL,
    "created_at" timestamp with time zone DEFAULT "timezone"('utc'::"text", "now"()) NOT NULL,
    CONSTRAINT "affiliate_referrals_status_check" CHECK (("status" = ANY (ARRAY['pending'::"text", 'active'::"text", 'converted'::"text"])))
);


ALTER TABLE "public"."affiliate_referrals" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."affiliate_withdrawals" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "user_id" "uuid" NOT NULL,
    "amount" numeric(10,2) NOT NULL,
    "mpesa_phone" "text",
    "status" "text" DEFAULT 'pending'::"text" NOT NULL,
    "created_at" timestamp with time zone DEFAULT "timezone"('utc'::"text", "now"()) NOT NULL,
    CONSTRAINT "affiliate_withdrawals_amount_check" CHECK (("amount" > (0)::numeric)),
    CONSTRAINT "affiliate_withdrawals_status_check" CHECK (("status" = ANY (ARRAY['pending'::"text", 'paid'::"text", 'rejected'::"text"])))
);


ALTER TABLE "public"."affiliate_withdrawals" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."blog_categories" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "name" "text" NOT NULL,
    "slug" "text" NOT NULL,
    "description" "text",
    "color_hex" "text" DEFAULT '#00A859'::"text",
    "display_order" integer DEFAULT 0,
    "is_active" boolean DEFAULT true,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL
);


ALTER TABLE "public"."blog_categories" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."blog_comments" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "post_id" "uuid",
    "parent_id" "uuid",
    "user_id" "uuid",
    "author_name" "text",
    "content" "text" NOT NULL,
    "status" "text" DEFAULT 'pending'::"text" NOT NULL,
    "is_reported" boolean DEFAULT false,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    CONSTRAINT "blog_comments_status_check" CHECK (("status" = ANY (ARRAY['pending'::"text", 'approved'::"text", 'rejected'::"text", 'reported'::"text", 'removed'::"text"])))
);


ALTER TABLE "public"."blog_comments" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."blog_post_tags" (
    "post_id" "uuid" NOT NULL,
    "tag_id" "uuid" NOT NULL
);


ALTER TABLE "public"."blog_post_tags" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."blog_post_views" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "post_id" "uuid",
    "user_id" "uuid",
    "ip_hash" "text",
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL
);


ALTER TABLE "public"."blog_post_views" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."blog_posts" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "slug" "text" NOT NULL,
    "title" "text" NOT NULL,
    "excerpt" "text",
    "content" "text",
    "cover_image_url" "text",
    "author_id" "uuid",
    "category_id" "uuid",
    "status" "text" DEFAULT 'draft'::"text" NOT NULL,
    "visibility" "text" DEFAULT 'public'::"text" NOT NULL,
    "is_featured" boolean DEFAULT false,
    "reading_time_minutes" integer DEFAULT 1,
    "view_count" integer DEFAULT 0,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "published_at" timestamp with time zone,
    "approved_at" timestamp with time zone,
    "approved_by" "uuid",
    "rejection_reason" "text",
    CONSTRAINT "blog_posts_status_check" CHECK (("status" = ANY (ARRAY['draft'::"text", 'pending'::"text", 'published'::"text", 'rejected'::"text", 'archived'::"text"]))),
    CONSTRAINT "blog_posts_visibility_check" CHECK (("visibility" = ANY (ARRAY['public'::"text", 'private'::"text", 'members'::"text"])))
);


ALTER TABLE "public"."blog_posts" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."blog_ratings" (
    "user_id" "uuid" NOT NULL,
    "post_id" "uuid" NOT NULL,
    "rating" numeric(2,1) NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    CONSTRAINT "blog_ratings_rating_check" CHECK ((("rating" >= 1.0) AND ("rating" <= 5.0)))
);


ALTER TABLE "public"."blog_ratings" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."blog_tags" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "name" "text" NOT NULL,
    "slug" "text" NOT NULL
);


ALTER TABLE "public"."blog_tags" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."contact_messages" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "name" "text" NOT NULL,
    "email" "text" NOT NULL,
    "subject" "text" NOT NULL,
    "message" "text" NOT NULL,
    "department" "text" DEFAULT 'general'::"text",
    "status" "text" DEFAULT 'new'::"text" NOT NULL,
    "source" "text" DEFAULT 'contact_form'::"text",
    "ip_address" "text",
    "user_agent" "text",
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "reply_text" "text",
    "replied_at" timestamp with time zone,
    "replied_by" "uuid",
    CONSTRAINT "contact_messages_status_check" CHECK (("status" = ANY (ARRAY['new'::"text", 'read'::"text", 'in_progress'::"text", 'resolved'::"text", 'spam'::"text"])))
);


ALTER TABLE "public"."contact_messages" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."drip_feed_settings" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "enabled" boolean DEFAULT true NOT NULL,
    "min_runs" integer NOT NULL,
    "max_runs" integer NOT NULL,
    "min_interval" integer NOT NULL,
    "max_interval" integer NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "timezone"('utc'::"text", "now"()) NOT NULL,
    CONSTRAINT "drip_feed_settings_max_interval_check" CHECK (("max_interval" >= 1)),
    CONSTRAINT "drip_feed_settings_max_runs_check" CHECK (("max_runs" >= 1)),
    CONSTRAINT "drip_feed_settings_min_interval_check" CHECK (("min_interval" >= 1)),
    CONSTRAINT "drip_feed_settings_min_runs_check" CHECK (("min_runs" >= 1))
);


ALTER TABLE "public"."drip_feed_settings" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."email_verifications" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "user_id" "uuid" NOT NULL,
    "token" "text" NOT NULL,
    "expires_at" timestamp with time zone NOT NULL,
    "created_at" timestamp with time zone DEFAULT "timezone"('utc'::"text", "now"()) NOT NULL
);


ALTER TABLE "public"."email_verifications" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."fulfillment_logs" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "order_id" "uuid",
    "provider_order_id" "text",
    "action" "text" NOT NULL,
    "status" "text" NOT NULL,
    "request_payload" "jsonb",
    "response_payload" "jsonb",
    "error" "text",
    "created_at" timestamp with time zone DEFAULT "timezone"('utc'::"text", "now"()) NOT NULL
);


ALTER TABLE "public"."fulfillment_logs" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."janjez_services" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "name" "text" NOT NULL,
    "slug" "text" NOT NULL,
    "category" "text" NOT NULL,
    "subcategory" "text",
    "description" "text",
    "selling_price_ksh" numeric(10,2) NOT NULL,
    "provider_service_id" "text" NOT NULL,
    "min_quantity" integer NOT NULL,
    "max_quantity" integer NOT NULL,
    "is_active" boolean DEFAULT true NOT NULL,
    "display_order" integer DEFAULT 0 NOT NULL,
    "supports_drip_feed" boolean DEFAULT false NOT NULL,
    "supports_refill" boolean DEFAULT false NOT NULL,
    "supports_cancel" boolean DEFAULT false NOT NULL,
    "created_at" timestamp with time zone DEFAULT "timezone"('utc'::"text", "now"()) NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "timezone"('utc'::"text", "now"()) NOT NULL,
    "show_sidebar" boolean DEFAULT false NOT NULL,
    "show_landing" boolean DEFAULT false NOT NULL,
    "show_guarded" boolean DEFAULT true NOT NULL,
    "show_anonymous" boolean DEFAULT true NOT NULL,
    "show_catalogue" boolean DEFAULT true NOT NULL,
    CONSTRAINT "janjez_services_max_quantity_check" CHECK (("max_quantity" > 0)),
    CONSTRAINT "janjez_services_min_quantity_check" CHECK (("min_quantity" > 0)),
    CONSTRAINT "janjez_services_selling_price_ksh_check" CHECK (("selling_price_ksh" >= (0)::numeric))
);


ALTER TABLE "public"."janjez_services" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."notifications" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "user_id" "uuid" NOT NULL,
    "type" "text",
    "title" "text" NOT NULL,
    "message" "text",
    "link" "text",
    "read" boolean DEFAULT false NOT NULL,
    "created_at" timestamp with time zone DEFAULT "timezone"('utc'::"text", "now"()) NOT NULL,
    "audience" "text" DEFAULT 'user'::"text" NOT NULL,
    "category" "text" DEFAULT 'system'::"text" NOT NULL,
    "severity" "text" DEFAULT 'info'::"text" NOT NULL,
    "body" "text",
    "read_at" timestamp with time zone,
    CONSTRAINT "notifications_audience_check" CHECK (("audience" = ANY (ARRAY['user'::"text", 'admin'::"text"]))),
    CONSTRAINT "notifications_category_check" CHECK (("category" = ANY (ARRAY['order'::"text", 'wallet'::"text", 'security'::"text", 'system'::"text", 'admin_alert'::"text"]))),
    CONSTRAINT "notifications_severity_check" CHECK (("severity" = ANY (ARRAY['info'::"text", 'success'::"text", 'warning'::"text", 'error'::"text"])))
);


ALTER TABLE "public"."notifications" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."orders" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "user_id" "uuid",
    "service_name" "text" NOT NULL,
    "service_id" "text",
    "link" "text" NOT NULL,
    "quantity" integer NOT NULL,
    "amount" numeric(10,2) NOT NULL,
    "comments" "text",
    "status" "text" DEFAULT 'pending'::"text" NOT NULL,
    "payment_status" "text" DEFAULT 'unpaid'::"text" NOT NULL,
    "created_at" timestamp with time zone DEFAULT "timezone"('utc'::"text", "now"()) NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "timezone"('utc'::"text", "now"()) NOT NULL,
    "category" "text",
    "subcategory" "text",
    "sku_id" "text",
    "link_submitted" "text",
    "amount_paid" numeric(10,2),
    "payment_reference" "text",
    "refill_guarantee" "text",
    "quantity_source" "text",
    "provider_service_id" "text",
    "provider_order_id" "text",
    "provider_status" "text",
    "provider_start_count" "text",
    "provider_remains" "text",
    "provider_currency" "text" DEFAULT 'USD'::"text",
    "provider_charge" numeric(10,5),
    "fulfillment_status" "text" DEFAULT 'pending'::"text",
    "fulfillment_error" "text",
    "fulfilled_at" timestamp with time zone,
    "order_id" "text",
    "catalog_category_id" "text",
    "runs" integer,
    "interval" integer,
    "janjez_service_id" "uuid",
    "phone_number" "text",
    "anonymous" boolean DEFAULT false NOT NULL,
    "idempotency_key" "text",
    CONSTRAINT "orders_amount_check" CHECK (("amount" >= (0)::numeric)),
    CONSTRAINT "orders_fulfillment_status_check" CHECK (("fulfillment_status" = ANY (ARRAY['pending'::"text", 'processing'::"text", 'fulfilled'::"text", 'failed'::"text", 'cancelled'::"text", 'refunded'::"text"]))),
    CONSTRAINT "orders_interval_check" CHECK (("interval" > 0)),
    CONSTRAINT "orders_payment_status_check" CHECK (("payment_status" = ANY (ARRAY['unpaid'::"text", 'pending_mpesa'::"text", 'paid'::"text", 'refunded'::"text"]))),
    CONSTRAINT "orders_quantity_check" CHECK (("quantity" > 0)),
    CONSTRAINT "orders_quantity_source_check" CHECK (("quantity_source" = ANY (ARRAY['preset'::"text", 'custom'::"text"]))),
    CONSTRAINT "orders_runs_check" CHECK (("runs" > 0)),
    CONSTRAINT "orders_status_check" CHECK (("status" = ANY (ARRAY['pending'::"text", 'processing'::"text", 'completed'::"text", 'cancelled'::"text", 'failed'::"text"])))
);


ALTER TABLE "public"."orders" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."password_reset_tokens" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "user_id" "uuid" NOT NULL,
    "token" "text" NOT NULL,
    "expires_at" timestamp with time zone NOT NULL,
    "used" boolean DEFAULT false NOT NULL,
    "created_at" timestamp with time zone DEFAULT "timezone"('utc'::"text", "now"()) NOT NULL
);


ALTER TABLE "public"."password_reset_tokens" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."platform_settings" (
    "key" "text" NOT NULL,
    "value" "jsonb" NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"()
);


ALTER TABLE "public"."platform_settings" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."profiles" (
    "id" "uuid" NOT NULL,
    "email" "text",
    "full_name" "text",
    "phone" "text",
    "wallet_balance" numeric(10,2) DEFAULT 0.00 NOT NULL,
    "created_at" timestamp with time zone DEFAULT "timezone"('utc'::"text", "now"()) NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "timezone"('utc'::"text", "now"()) NOT NULL,
    "email_verified" boolean DEFAULT false NOT NULL,
    "role" "text" DEFAULT 'user'::"text" NOT NULL,
    "avatar_url" "text",
    "notification_email" boolean DEFAULT true NOT NULL,
    "notification_sms" boolean DEFAULT false NOT NULL,
    "theme" "text" DEFAULT 'dark'::"text" NOT NULL,
    "language" "text" DEFAULT 'en'::"text" NOT NULL,
    "last_low_balance_email_at" timestamp with time zone,
    "username" "text",
    CONSTRAINT "profiles_username_format_check" CHECK ((("username" IS NULL) OR (("char_length"("username") >= 3) AND ("char_length"("username") <= 30) AND ("username" ~ '^[a-z0-9_]+$'::"text"))))
);


ALTER TABLE "public"."profiles" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."provider_services" (
    "id" "text" NOT NULL,
    "name" "text" NOT NULL,
    "type" "text",
    "category" "text",
    "rate" numeric(10,5) NOT NULL,
    "min" integer NOT NULL,
    "max" integer NOT NULL,
    "refill" boolean DEFAULT false,
    "cancel" boolean DEFAULT false,
    "raw" "jsonb",
    "fetched_at" timestamp with time zone DEFAULT "timezone"('utc'::"text", "now"()) NOT NULL,
    "provider_name" "text" DEFAULT 'DripFeedPanel'::"text",
    "subcategory" "text",
    "supports_drip_feed" boolean DEFAULT false,
    "is_active" boolean DEFAULT true,
    "last_synced_at" timestamp with time zone DEFAULT "timezone"('utc'::"text", "now"())
);


ALTER TABLE "public"."provider_services" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."security_events" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "user_id" "uuid" NOT NULL,
    "event_type" "text" NOT NULL,
    "ip" "text",
    "user_agent" "text",
    "metadata" "jsonb" DEFAULT '{}'::"jsonb" NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    CONSTRAINT "security_events_event_type_check" CHECK (("event_type" = ANY (ARRAY['signin'::"text", 'password_reset_requested'::"text", 'password_reset_completed'::"text"])))
);


ALTER TABLE "public"."security_events" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."service_mappings" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "platform_id" "text" NOT NULL,
    "subcategory_name" "text" NOT NULL,
    "deliverable_name" "text" NOT NULL,
    "provider_service_id" "text" NOT NULL,
    "match_reason" "text" DEFAULT 'cheapest'::"text",
    "is_active" boolean DEFAULT true NOT NULL,
    "created_at" timestamp with time zone DEFAULT "timezone"('utc'::"text", "now"()) NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "timezone"('utc'::"text", "now"()) NOT NULL,
    CONSTRAINT "service_mappings_match_reason_check" CHECK (("match_reason" = ANY (ARRAY['cheapest'::"text", 'manual'::"text", 'alias'::"text"])))
);


ALTER TABLE "public"."service_mappings" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."wallet_transactions" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "user_id" "uuid",
    "type" "text" NOT NULL,
    "amount" numeric(10,2) NOT NULL,
    "currency" "text" DEFAULT 'KES'::"text" NOT NULL,
    "reference" "text",
    "status" "text" DEFAULT 'completed'::"text" NOT NULL,
    "payment_method" "text",
    "mpesa_receipt" "text",
    "mpesa_phone" "text",
    "notes" "text",
    "created_at" timestamp with time zone DEFAULT "timezone"('utc'::"text", "now"()) NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "timezone"('utc'::"text", "now"()) NOT NULL,
    "related_order_id" "uuid",
    "phone_number" "text",
    CONSTRAINT "wallet_transactions_payment_method_check" CHECK (("payment_method" = ANY (ARRAY['mpesa'::"text", 'card'::"text", 'bank'::"text", 'other'::"text"]))),
    CONSTRAINT "wallet_transactions_status_check" CHECK (("status" = ANY (ARRAY['pending'::"text", 'completed'::"text", 'failed'::"text", 'reversed'::"text"]))),
    CONSTRAINT "wallet_transactions_type_check" CHECK (("type" = ANY (ARRAY['topup'::"text", 'spend'::"text", 'refund'::"text", 'bonus'::"text", 'adjustment'::"text", 'order_payment'::"text"])))
);


ALTER TABLE "public"."wallet_transactions" OWNER TO "postgres";


ALTER TABLE ONLY "public"."admin_activity_logs"
    ADD CONSTRAINT "admin_activity_logs_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."affiliate_earnings"
    ADD CONSTRAINT "affiliate_earnings_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."affiliate_referrals"
    ADD CONSTRAINT "affiliate_referrals_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."affiliate_withdrawals"
    ADD CONSTRAINT "affiliate_withdrawals_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."blog_categories"
    ADD CONSTRAINT "blog_categories_name_key" UNIQUE ("name");



ALTER TABLE ONLY "public"."blog_categories"
    ADD CONSTRAINT "blog_categories_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."blog_categories"
    ADD CONSTRAINT "blog_categories_slug_key" UNIQUE ("slug");



ALTER TABLE ONLY "public"."blog_comments"
    ADD CONSTRAINT "blog_comments_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."blog_post_tags"
    ADD CONSTRAINT "blog_post_tags_pkey" PRIMARY KEY ("post_id", "tag_id");



ALTER TABLE ONLY "public"."blog_post_views"
    ADD CONSTRAINT "blog_post_views_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."blog_posts"
    ADD CONSTRAINT "blog_posts_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."blog_posts"
    ADD CONSTRAINT "blog_posts_slug_key" UNIQUE ("slug");



ALTER TABLE ONLY "public"."blog_ratings"
    ADD CONSTRAINT "blog_ratings_pkey" PRIMARY KEY ("user_id", "post_id");



ALTER TABLE ONLY "public"."blog_tags"
    ADD CONSTRAINT "blog_tags_name_key" UNIQUE ("name");



ALTER TABLE ONLY "public"."blog_tags"
    ADD CONSTRAINT "blog_tags_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."blog_tags"
    ADD CONSTRAINT "blog_tags_slug_key" UNIQUE ("slug");



ALTER TABLE ONLY "public"."contact_messages"
    ADD CONSTRAINT "contact_messages_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."drip_feed_settings"
    ADD CONSTRAINT "drip_feed_settings_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."email_verifications"
    ADD CONSTRAINT "email_verifications_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."email_verifications"
    ADD CONSTRAINT "email_verifications_token_key" UNIQUE ("token");



ALTER TABLE ONLY "public"."fulfillment_logs"
    ADD CONSTRAINT "fulfillment_logs_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."janjez_services"
    ADD CONSTRAINT "janjez_services_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."janjez_services"
    ADD CONSTRAINT "janjez_services_slug_key" UNIQUE ("slug");



ALTER TABLE ONLY "public"."notifications"
    ADD CONSTRAINT "notifications_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."orders"
    ADD CONSTRAINT "orders_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."password_reset_tokens"
    ADD CONSTRAINT "password_reset_tokens_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."password_reset_tokens"
    ADD CONSTRAINT "password_reset_tokens_token_key" UNIQUE ("token");



ALTER TABLE ONLY "public"."platform_settings"
    ADD CONSTRAINT "platform_settings_pkey" PRIMARY KEY ("key");



ALTER TABLE ONLY "public"."profiles"
    ADD CONSTRAINT "profiles_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."provider_services"
    ADD CONSTRAINT "provider_services_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."security_events"
    ADD CONSTRAINT "security_events_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."service_mappings"
    ADD CONSTRAINT "service_mappings_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."service_mappings"
    ADD CONSTRAINT "service_mappings_platform_id_subcategory_name_deliverable_n_key" UNIQUE ("platform_id", "subcategory_name", "deliverable_name");



ALTER TABLE ONLY "public"."wallet_transactions"
    ADD CONSTRAINT "wallet_transactions_pkey" PRIMARY KEY ("id");



CREATE INDEX "idx_admin_activity_logs_action" ON "public"."admin_activity_logs" USING "btree" ("action");



CREATE INDEX "idx_admin_activity_logs_actor_id" ON "public"."admin_activity_logs" USING "btree" ("actor_id");



CREATE INDEX "idx_admin_activity_logs_created_at" ON "public"."admin_activity_logs" USING "btree" ("created_at" DESC);



CREATE INDEX "idx_affiliate_earnings_referrer" ON "public"."affiliate_earnings" USING "btree" ("referrer_id");



CREATE INDEX "idx_affiliate_earnings_status" ON "public"."affiliate_earnings" USING "btree" ("status");



CREATE INDEX "idx_affiliate_referrals_code" ON "public"."affiliate_referrals" USING "btree" ("code");



CREATE INDEX "idx_affiliate_referrals_referrer" ON "public"."affiliate_referrals" USING "btree" ("referrer_id");



CREATE INDEX "idx_affiliate_withdrawals_status" ON "public"."affiliate_withdrawals" USING "btree" ("status");



CREATE INDEX "idx_affiliate_withdrawals_user" ON "public"."affiliate_withdrawals" USING "btree" ("user_id");



CREATE INDEX "idx_blog_comments_parent" ON "public"."blog_comments" USING "btree" ("parent_id");



CREATE INDEX "idx_blog_comments_post" ON "public"."blog_comments" USING "btree" ("post_id");



CREATE INDEX "idx_blog_comments_status" ON "public"."blog_comments" USING "btree" ("status");



CREATE INDEX "idx_blog_post_tags_tag" ON "public"."blog_post_tags" USING "btree" ("tag_id");



CREATE INDEX "idx_blog_post_views_post" ON "public"."blog_post_views" USING "btree" ("post_id");



CREATE INDEX "idx_blog_posts_author" ON "public"."blog_posts" USING "btree" ("author_id");



CREATE INDEX "idx_blog_posts_category" ON "public"."blog_posts" USING "btree" ("category_id");



CREATE INDEX "idx_blog_posts_featured" ON "public"."blog_posts" USING "btree" ("is_featured") WHERE ("is_featured" = true);



CREATE INDEX "idx_blog_posts_published_at" ON "public"."blog_posts" USING "btree" ("published_at" DESC);



CREATE INDEX "idx_blog_posts_slug" ON "public"."blog_posts" USING "btree" ("slug");



CREATE INDEX "idx_blog_posts_status" ON "public"."blog_posts" USING "btree" ("status");



CREATE INDEX "idx_blog_ratings_post" ON "public"."blog_ratings" USING "btree" ("post_id");



CREATE INDEX "idx_contact_messages_created_at" ON "public"."contact_messages" USING "btree" ("created_at" DESC);



CREATE INDEX "idx_contact_messages_department" ON "public"."contact_messages" USING "btree" ("department");



CREATE INDEX "idx_contact_messages_replied_at" ON "public"."contact_messages" USING "btree" ("replied_at" DESC);



CREATE INDEX "idx_contact_messages_status" ON "public"."contact_messages" USING "btree" ("status");



CREATE INDEX "idx_fulfillment_logs_created_at" ON "public"."fulfillment_logs" USING "btree" ("created_at" DESC);



CREATE INDEX "idx_fulfillment_logs_order_id" ON "public"."fulfillment_logs" USING "btree" ("order_id");



CREATE INDEX "idx_fulfillment_logs_provider_order_id" ON "public"."fulfillment_logs" USING "btree" ("provider_order_id");



CREATE INDEX "idx_janjez_services_category" ON "public"."janjez_services" USING "btree" ("category");



CREATE INDEX "idx_janjez_services_display_order" ON "public"."janjez_services" USING "btree" ("display_order");



CREATE INDEX "idx_janjez_services_is_active" ON "public"."janjez_services" USING "btree" ("is_active");



CREATE INDEX "idx_janjez_services_provider_service" ON "public"."janjez_services" USING "btree" ("provider_service_id");



CREATE INDEX "idx_janjez_services_show_anonymous" ON "public"."janjez_services" USING "btree" ("show_anonymous") WHERE ("show_anonymous" = true);



CREATE INDEX "idx_janjez_services_show_catalogue" ON "public"."janjez_services" USING "btree" ("show_catalogue") WHERE ("show_catalogue" = true);



CREATE INDEX "idx_janjez_services_show_guarded" ON "public"."janjez_services" USING "btree" ("show_guarded") WHERE ("show_guarded" = true);



CREATE INDEX "idx_janjez_services_show_landing" ON "public"."janjez_services" USING "btree" ("show_landing") WHERE ("show_landing" = true);



CREATE INDEX "idx_janjez_services_show_sidebar" ON "public"."janjez_services" USING "btree" ("show_sidebar") WHERE ("show_sidebar" = true);



CREATE INDEX "idx_janjez_services_subcategory" ON "public"."janjez_services" USING "btree" ("subcategory");



CREATE INDEX "idx_notifications_audience_created_at" ON "public"."notifications" USING "btree" ("audience", "created_at" DESC);



CREATE INDEX "idx_notifications_created_at" ON "public"."notifications" USING "btree" ("created_at" DESC);



CREATE INDEX "idx_notifications_read" ON "public"."notifications" USING "btree" ("read");



CREATE INDEX "idx_notifications_user_id" ON "public"."notifications" USING "btree" ("user_id");



CREATE INDEX "idx_notifications_user_id_created_at" ON "public"."notifications" USING "btree" ("user_id", "created_at" DESC);



CREATE INDEX "idx_notifications_user_id_read_at" ON "public"."notifications" USING "btree" ("user_id", "read_at");



CREATE INDEX "idx_orders_catalog_category_id" ON "public"."orders" USING "btree" ("catalog_category_id");



CREATE INDEX "idx_orders_created_at" ON "public"."orders" USING "btree" ("created_at" DESC);



CREATE INDEX "idx_orders_fulfillment_status" ON "public"."orders" USING "btree" ("fulfillment_status");



CREATE INDEX "idx_orders_janjez_service_id" ON "public"."orders" USING "btree" ("janjez_service_id");



CREATE INDEX "idx_orders_order_id" ON "public"."orders" USING "btree" ("order_id");



CREATE INDEX "idx_orders_payment_reference" ON "public"."orders" USING "btree" ("payment_reference");



CREATE INDEX "idx_orders_payment_status" ON "public"."orders" USING "btree" ("payment_status");



CREATE INDEX "idx_orders_phone" ON "public"."orders" USING "btree" ("phone_number") WHERE ("phone_number" IS NOT NULL);



CREATE INDEX "idx_orders_provider_order_id" ON "public"."orders" USING "btree" ("provider_order_id");



CREATE INDEX "idx_orders_provider_service_id" ON "public"."orders" USING "btree" ("provider_service_id");



CREATE INDEX "idx_orders_sku_id" ON "public"."orders" USING "btree" ("sku_id");



CREATE INDEX "idx_orders_status" ON "public"."orders" USING "btree" ("status");



CREATE INDEX "idx_orders_user_id" ON "public"."orders" USING "btree" ("user_id");



CREATE UNIQUE INDEX "idx_orders_user_idempotency_key" ON "public"."orders" USING "btree" ("user_id", "idempotency_key") WHERE ("idempotency_key" IS NOT NULL);



CREATE INDEX "idx_password_reset_tokens_expires_at" ON "public"."password_reset_tokens" USING "btree" ("expires_at");



CREATE INDEX "idx_password_reset_tokens_token" ON "public"."password_reset_tokens" USING "btree" ("token");



CREATE INDEX "idx_password_reset_tokens_user_id" ON "public"."password_reset_tokens" USING "btree" ("user_id");



CREATE INDEX "idx_provider_services_category" ON "public"."provider_services" USING "btree" ("category");



CREATE INDEX "idx_provider_services_fetched_at" ON "public"."provider_services" USING "btree" ("fetched_at" DESC);



CREATE INDEX "idx_provider_services_is_active" ON "public"."provider_services" USING "btree" ("is_active");



CREATE INDEX "idx_provider_services_provider_name" ON "public"."provider_services" USING "btree" ("provider_name");



CREATE INDEX "idx_provider_services_rate" ON "public"."provider_services" USING "btree" ("rate");



CREATE INDEX "idx_provider_services_subcategory" ON "public"."provider_services" USING "btree" ("subcategory");



CREATE INDEX "idx_security_events_event_type_created_at" ON "public"."security_events" USING "btree" ("event_type", "created_at" DESC);



CREATE INDEX "idx_security_events_user_id_created_at" ON "public"."security_events" USING "btree" ("user_id", "created_at" DESC);



CREATE INDEX "idx_service_mappings_active" ON "public"."service_mappings" USING "btree" ("is_active") WHERE ("is_active" = true);



CREATE INDEX "idx_service_mappings_platform" ON "public"."service_mappings" USING "btree" ("platform_id");



CREATE INDEX "idx_service_mappings_provider_service" ON "public"."service_mappings" USING "btree" ("provider_service_id");



CREATE INDEX "idx_wallet_transactions_created_at" ON "public"."wallet_transactions" USING "btree" ("created_at" DESC);



CREATE INDEX "idx_wallet_transactions_order" ON "public"."wallet_transactions" USING "btree" ("related_order_id") WHERE ("related_order_id" IS NOT NULL);



CREATE INDEX "idx_wallet_transactions_status" ON "public"."wallet_transactions" USING "btree" ("status");



CREATE INDEX "idx_wallet_transactions_type" ON "public"."wallet_transactions" USING "btree" ("type");



CREATE INDEX "idx_wallet_transactions_user_id" ON "public"."wallet_transactions" USING "btree" ("user_id");



CREATE UNIQUE INDEX "platform_settings_key_idx" ON "public"."platform_settings" USING "btree" ("key");



CREATE UNIQUE INDEX "profiles_username_lower_unique_idx" ON "public"."profiles" USING "btree" ("lower"("username")) WHERE ("username" IS NOT NULL);



CREATE OR REPLACE TRIGGER "on_janjez_service_updated" BEFORE UPDATE ON "public"."janjez_services" FOR EACH ROW EXECUTE FUNCTION "public"."update_janjez_service_timestamp"();



CREATE OR REPLACE TRIGGER "on_order_insert" BEFORE INSERT ON "public"."orders" FOR EACH ROW EXECUTE FUNCTION "public"."generate_order_id"();



CREATE OR REPLACE TRIGGER "on_order_updated" BEFORE UPDATE ON "public"."orders" FOR EACH ROW EXECUTE FUNCTION "public"."update_order_timestamp"();



CREATE OR REPLACE TRIGGER "on_profile_updated" BEFORE UPDATE ON "public"."profiles" FOR EACH ROW EXECUTE FUNCTION "public"."update_profile_timestamp"();



CREATE OR REPLACE TRIGGER "on_service_mapping_updated" BEFORE UPDATE ON "public"."service_mappings" FOR EACH ROW EXECUTE FUNCTION "public"."update_service_mapping_timestamp"();



CREATE OR REPLACE TRIGGER "on_transaction_updated" BEFORE UPDATE ON "public"."wallet_transactions" FOR EACH ROW EXECUTE FUNCTION "public"."update_transaction_timestamp"();



ALTER TABLE ONLY "public"."admin_activity_logs"
    ADD CONSTRAINT "admin_activity_logs_actor_id_fkey" FOREIGN KEY ("actor_id") REFERENCES "public"."profiles"("id") ON DELETE SET NULL;



ALTER TABLE ONLY "public"."affiliate_earnings"
    ADD CONSTRAINT "affiliate_earnings_order_id_fkey" FOREIGN KEY ("order_id") REFERENCES "public"."orders"("id") ON DELETE SET NULL;



ALTER TABLE ONLY "public"."affiliate_earnings"
    ADD CONSTRAINT "affiliate_earnings_referrer_id_fkey" FOREIGN KEY ("referrer_id") REFERENCES "public"."profiles"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."affiliate_referrals"
    ADD CONSTRAINT "affiliate_referrals_referee_id_fkey" FOREIGN KEY ("referee_id") REFERENCES "public"."profiles"("id") ON DELETE SET NULL;



ALTER TABLE ONLY "public"."affiliate_referrals"
    ADD CONSTRAINT "affiliate_referrals_referrer_id_fkey" FOREIGN KEY ("referrer_id") REFERENCES "public"."profiles"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."affiliate_withdrawals"
    ADD CONSTRAINT "affiliate_withdrawals_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "public"."profiles"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."blog_comments"
    ADD CONSTRAINT "blog_comments_parent_id_fkey" FOREIGN KEY ("parent_id") REFERENCES "public"."blog_comments"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."blog_comments"
    ADD CONSTRAINT "blog_comments_post_id_fkey" FOREIGN KEY ("post_id") REFERENCES "public"."blog_posts"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."blog_comments"
    ADD CONSTRAINT "blog_comments_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "public"."profiles"("id") ON DELETE SET NULL;



ALTER TABLE ONLY "public"."blog_post_tags"
    ADD CONSTRAINT "blog_post_tags_post_id_fkey" FOREIGN KEY ("post_id") REFERENCES "public"."blog_posts"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."blog_post_tags"
    ADD CONSTRAINT "blog_post_tags_tag_id_fkey" FOREIGN KEY ("tag_id") REFERENCES "public"."blog_tags"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."blog_post_views"
    ADD CONSTRAINT "blog_post_views_post_id_fkey" FOREIGN KEY ("post_id") REFERENCES "public"."blog_posts"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."blog_post_views"
    ADD CONSTRAINT "blog_post_views_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "public"."profiles"("id") ON DELETE SET NULL;



ALTER TABLE ONLY "public"."blog_posts"
    ADD CONSTRAINT "blog_posts_approved_by_fkey" FOREIGN KEY ("approved_by") REFERENCES "public"."profiles"("id") ON DELETE SET NULL;



ALTER TABLE ONLY "public"."blog_posts"
    ADD CONSTRAINT "blog_posts_author_id_fkey" FOREIGN KEY ("author_id") REFERENCES "public"."profiles"("id") ON DELETE SET NULL;



ALTER TABLE ONLY "public"."blog_posts"
    ADD CONSTRAINT "blog_posts_category_id_fkey" FOREIGN KEY ("category_id") REFERENCES "public"."blog_categories"("id") ON DELETE SET NULL;



ALTER TABLE ONLY "public"."blog_ratings"
    ADD CONSTRAINT "blog_ratings_post_id_fkey" FOREIGN KEY ("post_id") REFERENCES "public"."blog_posts"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."blog_ratings"
    ADD CONSTRAINT "blog_ratings_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "public"."profiles"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."contact_messages"
    ADD CONSTRAINT "contact_messages_replied_by_fkey" FOREIGN KEY ("replied_by") REFERENCES "public"."profiles"("id") ON DELETE SET NULL;



ALTER TABLE ONLY "public"."email_verifications"
    ADD CONSTRAINT "email_verifications_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "public"."profiles"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."fulfillment_logs"
    ADD CONSTRAINT "fulfillment_logs_order_id_fkey" FOREIGN KEY ("order_id") REFERENCES "public"."orders"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."janjez_services"
    ADD CONSTRAINT "janjez_services_provider_service_id_fkey" FOREIGN KEY ("provider_service_id") REFERENCES "public"."provider_services"("id") ON DELETE RESTRICT;



ALTER TABLE ONLY "public"."notifications"
    ADD CONSTRAINT "notifications_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "public"."profiles"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."orders"
    ADD CONSTRAINT "orders_janjez_service_id_fkey" FOREIGN KEY ("janjez_service_id") REFERENCES "public"."janjez_services"("id") ON DELETE SET NULL;



ALTER TABLE ONLY "public"."orders"
    ADD CONSTRAINT "orders_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "public"."profiles"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."password_reset_tokens"
    ADD CONSTRAINT "password_reset_tokens_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "public"."profiles"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."profiles"
    ADD CONSTRAINT "profiles_id_fkey" FOREIGN KEY ("id") REFERENCES "auth"."users"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."security_events"
    ADD CONSTRAINT "security_events_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "public"."profiles"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."service_mappings"
    ADD CONSTRAINT "service_mappings_provider_service_id_fkey" FOREIGN KEY ("provider_service_id") REFERENCES "public"."provider_services"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."wallet_transactions"
    ADD CONSTRAINT "wallet_transactions_related_order_id_fkey" FOREIGN KEY ("related_order_id") REFERENCES "public"."orders"("id") ON DELETE SET NULL;



ALTER TABLE ONLY "public"."wallet_transactions"
    ADD CONSTRAINT "wallet_transactions_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "public"."profiles"("id") ON DELETE CASCADE;



CREATE POLICY "Admins can delete password reset tokens" ON "public"."password_reset_tokens" FOR DELETE USING ((EXISTS ( SELECT 1
   FROM "public"."profiles"
  WHERE (("profiles"."id" = "auth"."uid"()) AND ("profiles"."role" = 'admin'::"text")))));



CREATE POLICY "Admins can insert activity logs" ON "public"."admin_activity_logs" FOR INSERT WITH CHECK ((EXISTS ( SELECT 1
   FROM "public"."profiles"
  WHERE (("profiles"."id" = "auth"."uid"()) AND ("profiles"."role" = 'admin'::"text")))));



CREATE POLICY "Admins can insert password reset tokens" ON "public"."password_reset_tokens" FOR INSERT WITH CHECK ((EXISTS ( SELECT 1
   FROM "public"."profiles"
  WHERE (("profiles"."id" = "auth"."uid"()) AND ("profiles"."role" = 'admin'::"text")))));



CREATE POLICY "Admins can insert transactions" ON "public"."wallet_transactions" FOR INSERT WITH CHECK ((EXISTS ( SELECT 1
   FROM "public"."profiles"
  WHERE (("profiles"."id" = "auth"."uid"()) AND ("profiles"."role" = 'admin'::"text")))));



CREATE POLICY "Admins can manage categories" ON "public"."blog_categories" USING ((EXISTS ( SELECT 1
   FROM "public"."profiles"
  WHERE (("profiles"."id" = "auth"."uid"()) AND ("profiles"."role" = 'admin'::"text")))));



CREATE POLICY "Admins can manage drip feed settings" ON "public"."drip_feed_settings" USING ((EXISTS ( SELECT 1
   FROM "public"."profiles"
  WHERE (("profiles"."id" = "auth"."uid"()) AND ("profiles"."role" = 'admin'::"text")))));



CREATE POLICY "Admins can manage earnings" ON "public"."affiliate_earnings" USING ((EXISTS ( SELECT 1
   FROM "public"."profiles"
  WHERE (("profiles"."id" = "auth"."uid"()) AND ("profiles"."role" = 'admin'::"text")))));



CREATE POLICY "Admins can manage janjez services" ON "public"."janjez_services" USING ((EXISTS ( SELECT 1
   FROM "public"."profiles"
  WHERE (("profiles"."id" = "auth"."uid"()) AND ("profiles"."role" = 'admin'::"text")))));



CREATE POLICY "Admins can manage provider services" ON "public"."provider_services" USING ((EXISTS ( SELECT 1
   FROM "public"."profiles"
  WHERE (("profiles"."id" = "auth"."uid"()) AND ("profiles"."role" = 'admin'::"text")))));



CREATE POLICY "Admins can manage service mappings" ON "public"."service_mappings" USING ((EXISTS ( SELECT 1
   FROM "public"."profiles"
  WHERE (("profiles"."id" = "auth"."uid"()) AND ("profiles"."role" = 'admin'::"text")))));



CREATE POLICY "Admins can manage tags" ON "public"."blog_tags" USING ((EXISTS ( SELECT 1
   FROM "public"."profiles"
  WHERE (("profiles"."id" = "auth"."uid"()) AND ("profiles"."role" = 'admin'::"text")))));



CREATE POLICY "Admins can manage withdrawals" ON "public"."affiliate_withdrawals" USING ((EXISTS ( SELECT 1
   FROM "public"."profiles"
  WHERE (("profiles"."id" = "auth"."uid"()) AND ("profiles"."role" = 'admin'::"text")))));



CREATE POLICY "Admins can moderate comments" ON "public"."blog_comments" USING ((EXISTS ( SELECT 1
   FROM "public"."profiles"
  WHERE (("profiles"."id" = "auth"."uid"()) AND ("profiles"."role" = 'admin'::"text")))));



CREATE POLICY "Admins can read all posts" ON "public"."blog_posts" FOR SELECT USING ((EXISTS ( SELECT 1
   FROM "public"."profiles"
  WHERE (("profiles"."id" = "auth"."uid"()) AND ("profiles"."role" = 'admin'::"text")))));



CREATE POLICY "Admins can update all orders" ON "public"."orders" FOR UPDATE USING ((EXISTS ( SELECT 1
   FROM "public"."profiles"
  WHERE (("profiles"."id" = "auth"."uid"()) AND ("profiles"."role" = 'admin'::"text")))));



CREATE POLICY "Admins can update all posts" ON "public"."blog_posts" FOR UPDATE USING ((EXISTS ( SELECT 1
   FROM "public"."profiles"
  WHERE (("profiles"."id" = "auth"."uid"()) AND ("profiles"."role" = 'admin'::"text")))));



CREATE POLICY "Admins can update password reset tokens" ON "public"."password_reset_tokens" FOR UPDATE USING ((EXISTS ( SELECT 1
   FROM "public"."profiles"
  WHERE (("profiles"."id" = "auth"."uid"()) AND ("profiles"."role" = 'admin'::"text")))));



CREATE POLICY "Admins can view all activity logs" ON "public"."admin_activity_logs" FOR SELECT USING ((EXISTS ( SELECT 1
   FROM "public"."profiles"
  WHERE (("profiles"."id" = "auth"."uid"()) AND ("profiles"."role" = 'admin'::"text")))));



CREATE POLICY "Admins can view all orders" ON "public"."orders" FOR SELECT USING ((EXISTS ( SELECT 1
   FROM "public"."profiles"
  WHERE (("profiles"."id" = "auth"."uid"()) AND ("profiles"."role" = 'admin'::"text")))));



CREATE POLICY "Admins can view all transactions" ON "public"."wallet_transactions" FOR SELECT USING ((EXISTS ( SELECT 1
   FROM "public"."profiles"
  WHERE (("profiles"."id" = "auth"."uid"()) AND ("profiles"."role" = 'admin'::"text")))));



CREATE POLICY "Admins can view fulfillment logs" ON "public"."fulfillment_logs" FOR SELECT USING ((EXISTS ( SELECT 1
   FROM "public"."profiles"
  WHERE (("profiles"."id" = "auth"."uid"()) AND ("profiles"."role" = 'admin'::"text")))));



CREATE POLICY "Admins can view password reset tokens" ON "public"."password_reset_tokens" FOR SELECT USING ((EXISTS ( SELECT 1
   FROM "public"."profiles"
  WHERE (("profiles"."id" = "auth"."uid"()) AND ("profiles"."role" = 'admin'::"text")))));



CREATE POLICY "Allow admin read" ON "public"."contact_messages" FOR SELECT USING ((EXISTS ( SELECT 1
   FROM "public"."profiles"
  WHERE (("profiles"."id" = "auth"."uid"()) AND ("profiles"."role" = 'admin'::"text")))));



CREATE POLICY "Allow admin update" ON "public"."contact_messages" FOR UPDATE USING ((EXISTS ( SELECT 1
   FROM "public"."profiles"
  WHERE (("profiles"."id" = "auth"."uid"()) AND ("profiles"."role" = 'admin'::"text")))));



CREATE POLICY "Allow public insert" ON "public"."contact_messages" FOR INSERT WITH CHECK (true);



CREATE POLICY "Authenticated users can comment" ON "public"."blog_comments" FOR INSERT WITH CHECK (("auth"."uid"() = "user_id"));



CREATE POLICY "Authenticated users can log views" ON "public"."blog_post_views" FOR INSERT WITH CHECK ((("auth"."uid"() = "user_id") OR ("user_id" IS NULL)));



CREATE POLICY "Authenticated users can rate" ON "public"."blog_ratings" FOR INSERT WITH CHECK (("auth"."uid"() = "user_id"));



CREATE POLICY "Authenticated users can view usernames" ON "public"."profiles" FOR SELECT USING (("auth"."role"() = 'authenticated'::"text"));



CREATE POLICY "Authors can insert draft posts" ON "public"."blog_posts" FOR INSERT WITH CHECK (("auth"."uid"() = "author_id"));



CREATE POLICY "Authors can read own comments" ON "public"."blog_comments" FOR SELECT USING (("auth"."uid"() = "user_id"));



CREATE POLICY "Authors can read own posts" ON "public"."blog_posts" FOR SELECT USING (("auth"."uid"() = "author_id"));



CREATE POLICY "Authors can update own drafts" ON "public"."blog_posts" FOR UPDATE USING (("auth"."uid"() = "author_id"));



CREATE POLICY "Categories are publicly readable" ON "public"."blog_categories" FOR SELECT USING (true);



CREATE POLICY "Comment authors can edit own comments" ON "public"."blog_comments" FOR UPDATE USING (("auth"."uid"() = "user_id"));



CREATE POLICY "Post tags are publicly readable" ON "public"."blog_post_tags" FOR SELECT USING (true);



CREATE POLICY "Public can read approved comments" ON "public"."blog_comments" FOR SELECT USING (("status" = 'approved'::"text"));



CREATE POLICY "Public can read published posts" ON "public"."blog_posts" FOR SELECT USING ((("status" = 'published'::"text") AND ("visibility" = ANY (ARRAY['public'::"text", 'members'::"text"]))));



CREATE POLICY "Public can view active janjez services" ON "public"."janjez_services" FOR SELECT USING (("is_active" = true));



CREATE POLICY "Public can view drip feed settings" ON "public"."drip_feed_settings" FOR SELECT USING (true);



CREATE POLICY "Ratings are publicly readable" ON "public"."blog_ratings" FOR SELECT USING (true);



CREATE POLICY "Service role can manage anonymous orders" ON "public"."orders" TO "service_role" USING (true) WITH CHECK (true);



CREATE POLICY "Service role can manage anonymous transactions" ON "public"."wallet_transactions" TO "service_role" USING (true) WITH CHECK (true);



CREATE POLICY "Service role can manage password reset tokens" ON "public"."password_reset_tokens" TO "service_role" USING (true) WITH CHECK (true);



CREATE POLICY "System can insert fulfillment logs" ON "public"."fulfillment_logs" FOR INSERT WITH CHECK (true);



CREATE POLICY "Tags are publicly readable" ON "public"."blog_tags" FOR SELECT USING (true);



CREATE POLICY "Users can create referrals" ON "public"."affiliate_referrals" FOR INSERT WITH CHECK (true);



CREATE POLICY "Users can create withdrawals" ON "public"."affiliate_withdrawals" FOR INSERT WITH CHECK (("auth"."uid"() = "user_id"));



CREATE POLICY "Users can insert own orders" ON "public"."orders" FOR INSERT WITH CHECK (("auth"."uid"() = "user_id"));



CREATE POLICY "Users can insert own profile" ON "public"."profiles" FOR INSERT WITH CHECK (("auth"."uid"() = "id"));



CREATE POLICY "Users can insert own transactions" ON "public"."wallet_transactions" FOR INSERT WITH CHECK (("auth"."uid"() = "user_id"));



CREATE POLICY "Users can insert own verification records" ON "public"."email_verifications" FOR INSERT WITH CHECK (("auth"."uid"() = "user_id"));



CREATE POLICY "Users can update own orders" ON "public"."orders" FOR UPDATE USING (("auth"."uid"() = "user_id"));



CREATE POLICY "Users can update own profile" ON "public"."profiles" FOR UPDATE USING (("auth"."uid"() = "id"));



CREATE POLICY "Users can update own profile username" ON "public"."profiles" FOR UPDATE USING (("auth"."uid"() = "id"));



CREATE POLICY "Users can update own ratings" ON "public"."blog_ratings" FOR UPDATE USING (("auth"."uid"() = "user_id"));



CREATE POLICY "Users can view own earnings" ON "public"."affiliate_earnings" FOR SELECT USING (("auth"."uid"() = "referrer_id"));



CREATE POLICY "Users can view own orders" ON "public"."orders" FOR SELECT USING (("auth"."uid"() = "user_id"));



CREATE POLICY "Users can view own profile" ON "public"."profiles" FOR SELECT USING (("auth"."uid"() = "id"));



CREATE POLICY "Users can view own referrals" ON "public"."affiliate_referrals" FOR SELECT USING (("auth"."uid"() = "referrer_id"));



CREATE POLICY "Users can view own transactions" ON "public"."wallet_transactions" FOR SELECT USING (("auth"."uid"() = "user_id"));



CREATE POLICY "Users can view own verification records" ON "public"."email_verifications" FOR SELECT USING (("auth"."uid"() = "user_id"));



CREATE POLICY "Users can view own withdrawals" ON "public"."affiliate_withdrawals" FOR SELECT USING (("auth"."uid"() = "user_id"));



CREATE POLICY "Views are readable by authenticated users" ON "public"."blog_post_views" FOR SELECT USING (true);



ALTER TABLE "public"."admin_activity_logs" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "public"."affiliate_earnings" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "public"."affiliate_referrals" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "public"."affiliate_withdrawals" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "public"."blog_categories" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "public"."blog_comments" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "public"."blog_post_tags" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "public"."blog_post_views" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "public"."blog_posts" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "public"."blog_ratings" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "public"."blog_tags" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "public"."contact_messages" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "public"."drip_feed_settings" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "public"."email_verifications" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "public"."fulfillment_logs" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "public"."janjez_services" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "public"."notifications" ENABLE ROW LEVEL SECURITY;


CREATE POLICY "notifications_admin_delete_all" ON "public"."notifications" FOR DELETE USING (((EXISTS ( SELECT 1
   FROM "public"."profiles"
  WHERE (("profiles"."id" = "auth"."uid"()) AND ("profiles"."role" = 'admin'::"text")))) OR ("auth"."uid"() = "user_id")));



CREATE POLICY "notifications_admin_insert" ON "public"."notifications" FOR INSERT WITH CHECK (((EXISTS ( SELECT 1
   FROM "public"."profiles"
  WHERE (("profiles"."id" = "auth"."uid"()) AND ("profiles"."role" = 'admin'::"text")))) OR ("auth"."uid"() = "user_id")));



CREATE POLICY "notifications_admin_select_all" ON "public"."notifications" FOR SELECT USING ((EXISTS ( SELECT 1
   FROM "public"."profiles"
  WHERE (("profiles"."id" = "auth"."uid"()) AND ("profiles"."role" = 'admin'::"text")))));



CREATE POLICY "notifications_admin_update_all" ON "public"."notifications" FOR UPDATE USING ((EXISTS ( SELECT 1
   FROM "public"."profiles"
  WHERE (("profiles"."id" = "auth"."uid"()) AND ("profiles"."role" = 'admin'::"text"))))) WITH CHECK ((EXISTS ( SELECT 1
   FROM "public"."profiles"
  WHERE (("profiles"."id" = "auth"."uid"()) AND ("profiles"."role" = 'admin'::"text")))));



CREATE POLICY "notifications_select_own_or_admin_audience" ON "public"."notifications" FOR SELECT USING ((("auth"."uid"() = "user_id") OR ("audience" = 'admin'::"text")));



CREATE POLICY "notifications_update_own" ON "public"."notifications" FOR UPDATE USING (("auth"."uid"() = "user_id")) WITH CHECK (("auth"."uid"() = "user_id"));



ALTER TABLE "public"."orders" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "public"."password_reset_tokens" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "public"."platform_settings" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "public"."profiles" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "public"."provider_services" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "public"."security_events" ENABLE ROW LEVEL SECURITY;


CREATE POLICY "security_events_select_own" ON "public"."security_events" FOR SELECT USING (("auth"."uid"() = "user_id"));



CREATE POLICY "security_events_service_role_insert" ON "public"."security_events" FOR INSERT WITH CHECK (true);



ALTER TABLE "public"."service_mappings" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "public"."wallet_transactions" ENABLE ROW LEVEL SECURITY;




ALTER PUBLICATION "supabase_realtime" OWNER TO "postgres";






ALTER PUBLICATION "supabase_realtime" ADD TABLE ONLY "public"."notifications";






GRANT USAGE ON SCHEMA "public" TO "postgres";
GRANT USAGE ON SCHEMA "public" TO "anon";
GRANT USAGE ON SCHEMA "public" TO "authenticated";
GRANT USAGE ON SCHEMA "public" TO "service_role";











































































































































































GRANT ALL ON FUNCTION "public"."credit_wallet"("p_user_id" "uuid", "p_amount" numeric) TO "anon";
GRANT ALL ON FUNCTION "public"."credit_wallet"("p_user_id" "uuid", "p_amount" numeric) TO "authenticated";
GRANT ALL ON FUNCTION "public"."credit_wallet"("p_user_id" "uuid", "p_amount" numeric) TO "service_role";



GRANT ALL ON FUNCTION "public"."debit_wallet"("p_user_id" "uuid", "p_amount" numeric) TO "anon";
GRANT ALL ON FUNCTION "public"."debit_wallet"("p_user_id" "uuid", "p_amount" numeric) TO "authenticated";
GRANT ALL ON FUNCTION "public"."debit_wallet"("p_user_id" "uuid", "p_amount" numeric) TO "service_role";



GRANT ALL ON FUNCTION "public"."generate_order_id"() TO "anon";
GRANT ALL ON FUNCTION "public"."generate_order_id"() TO "authenticated";
GRANT ALL ON FUNCTION "public"."generate_order_id"() TO "service_role";



GRANT ALL ON FUNCTION "public"."get_anonymous_order"("p_order_id" "uuid", "p_phone" "text") TO "anon";
GRANT ALL ON FUNCTION "public"."get_anonymous_order"("p_order_id" "uuid", "p_phone" "text") TO "authenticated";
GRANT ALL ON FUNCTION "public"."get_anonymous_order"("p_order_id" "uuid", "p_phone" "text") TO "service_role";



GRANT ALL ON FUNCTION "public"."handle_new_user"() TO "anon";
GRANT ALL ON FUNCTION "public"."handle_new_user"() TO "authenticated";
GRANT ALL ON FUNCTION "public"."handle_new_user"() TO "service_role";



GRANT ALL ON FUNCTION "public"."increment_blog_view"("p_post_id" "uuid") TO "anon";
GRANT ALL ON FUNCTION "public"."increment_blog_view"("p_post_id" "uuid") TO "authenticated";
GRANT ALL ON FUNCTION "public"."increment_blog_view"("p_post_id" "uuid") TO "service_role";



GRANT ALL ON FUNCTION "public"."rls_auto_enable"() TO "anon";
GRANT ALL ON FUNCTION "public"."rls_auto_enable"() TO "authenticated";
GRANT ALL ON FUNCTION "public"."rls_auto_enable"() TO "service_role";



GRANT ALL ON FUNCTION "public"."sync_email_verified"() TO "anon";
GRANT ALL ON FUNCTION "public"."sync_email_verified"() TO "authenticated";
GRANT ALL ON FUNCTION "public"."sync_email_verified"() TO "service_role";



GRANT ALL ON FUNCTION "public"."update_janjez_service_timestamp"() TO "anon";
GRANT ALL ON FUNCTION "public"."update_janjez_service_timestamp"() TO "authenticated";
GRANT ALL ON FUNCTION "public"."update_janjez_service_timestamp"() TO "service_role";



GRANT ALL ON FUNCTION "public"."update_order_timestamp"() TO "anon";
GRANT ALL ON FUNCTION "public"."update_order_timestamp"() TO "authenticated";
GRANT ALL ON FUNCTION "public"."update_order_timestamp"() TO "service_role";



GRANT ALL ON FUNCTION "public"."update_profile_timestamp"() TO "anon";
GRANT ALL ON FUNCTION "public"."update_profile_timestamp"() TO "authenticated";
GRANT ALL ON FUNCTION "public"."update_profile_timestamp"() TO "service_role";



GRANT ALL ON FUNCTION "public"."update_service_mapping_timestamp"() TO "anon";
GRANT ALL ON FUNCTION "public"."update_service_mapping_timestamp"() TO "authenticated";
GRANT ALL ON FUNCTION "public"."update_service_mapping_timestamp"() TO "service_role";



GRANT ALL ON FUNCTION "public"."update_transaction_timestamp"() TO "anon";
GRANT ALL ON FUNCTION "public"."update_transaction_timestamp"() TO "authenticated";
GRANT ALL ON FUNCTION "public"."update_transaction_timestamp"() TO "service_role";
























GRANT ALL ON TABLE "public"."admin_activity_logs" TO "anon";
GRANT ALL ON TABLE "public"."admin_activity_logs" TO "authenticated";
GRANT ALL ON TABLE "public"."admin_activity_logs" TO "service_role";



GRANT ALL ON TABLE "public"."affiliate_earnings" TO "anon";
GRANT ALL ON TABLE "public"."affiliate_earnings" TO "authenticated";
GRANT ALL ON TABLE "public"."affiliate_earnings" TO "service_role";



GRANT ALL ON TABLE "public"."affiliate_referrals" TO "anon";
GRANT ALL ON TABLE "public"."affiliate_referrals" TO "authenticated";
GRANT ALL ON TABLE "public"."affiliate_referrals" TO "service_role";



GRANT ALL ON TABLE "public"."affiliate_withdrawals" TO "anon";
GRANT ALL ON TABLE "public"."affiliate_withdrawals" TO "authenticated";
GRANT ALL ON TABLE "public"."affiliate_withdrawals" TO "service_role";



GRANT ALL ON TABLE "public"."blog_categories" TO "anon";
GRANT ALL ON TABLE "public"."blog_categories" TO "authenticated";
GRANT ALL ON TABLE "public"."blog_categories" TO "service_role";



GRANT ALL ON TABLE "public"."blog_comments" TO "anon";
GRANT ALL ON TABLE "public"."blog_comments" TO "authenticated";
GRANT ALL ON TABLE "public"."blog_comments" TO "service_role";



GRANT ALL ON TABLE "public"."blog_post_tags" TO "anon";
GRANT ALL ON TABLE "public"."blog_post_tags" TO "authenticated";
GRANT ALL ON TABLE "public"."blog_post_tags" TO "service_role";



GRANT ALL ON TABLE "public"."blog_post_views" TO "anon";
GRANT ALL ON TABLE "public"."blog_post_views" TO "authenticated";
GRANT ALL ON TABLE "public"."blog_post_views" TO "service_role";



GRANT ALL ON TABLE "public"."blog_posts" TO "anon";
GRANT ALL ON TABLE "public"."blog_posts" TO "authenticated";
GRANT ALL ON TABLE "public"."blog_posts" TO "service_role";



GRANT ALL ON TABLE "public"."blog_ratings" TO "anon";
GRANT ALL ON TABLE "public"."blog_ratings" TO "authenticated";
GRANT ALL ON TABLE "public"."blog_ratings" TO "service_role";



GRANT ALL ON TABLE "public"."blog_tags" TO "anon";
GRANT ALL ON TABLE "public"."blog_tags" TO "authenticated";
GRANT ALL ON TABLE "public"."blog_tags" TO "service_role";



GRANT ALL ON TABLE "public"."contact_messages" TO "anon";
GRANT ALL ON TABLE "public"."contact_messages" TO "authenticated";
GRANT ALL ON TABLE "public"."contact_messages" TO "service_role";



GRANT ALL ON TABLE "public"."drip_feed_settings" TO "anon";
GRANT ALL ON TABLE "public"."drip_feed_settings" TO "authenticated";
GRANT ALL ON TABLE "public"."drip_feed_settings" TO "service_role";



GRANT ALL ON TABLE "public"."email_verifications" TO "anon";
GRANT ALL ON TABLE "public"."email_verifications" TO "authenticated";
GRANT ALL ON TABLE "public"."email_verifications" TO "service_role";



GRANT ALL ON TABLE "public"."fulfillment_logs" TO "anon";
GRANT ALL ON TABLE "public"."fulfillment_logs" TO "authenticated";
GRANT ALL ON TABLE "public"."fulfillment_logs" TO "service_role";



GRANT ALL ON TABLE "public"."janjez_services" TO "anon";
GRANT ALL ON TABLE "public"."janjez_services" TO "authenticated";
GRANT ALL ON TABLE "public"."janjez_services" TO "service_role";



GRANT ALL ON TABLE "public"."notifications" TO "anon";
GRANT ALL ON TABLE "public"."notifications" TO "authenticated";
GRANT ALL ON TABLE "public"."notifications" TO "service_role";



GRANT ALL ON TABLE "public"."orders" TO "anon";
GRANT ALL ON TABLE "public"."orders" TO "authenticated";
GRANT ALL ON TABLE "public"."orders" TO "service_role";



GRANT ALL ON TABLE "public"."password_reset_tokens" TO "anon";
GRANT ALL ON TABLE "public"."password_reset_tokens" TO "authenticated";
GRANT ALL ON TABLE "public"."password_reset_tokens" TO "service_role";



GRANT ALL ON TABLE "public"."platform_settings" TO "anon";
GRANT ALL ON TABLE "public"."platform_settings" TO "authenticated";
GRANT ALL ON TABLE "public"."platform_settings" TO "service_role";



GRANT ALL ON TABLE "public"."profiles" TO "anon";
GRANT ALL ON TABLE "public"."profiles" TO "authenticated";
GRANT ALL ON TABLE "public"."profiles" TO "service_role";



GRANT ALL ON TABLE "public"."provider_services" TO "anon";
GRANT ALL ON TABLE "public"."provider_services" TO "authenticated";
GRANT ALL ON TABLE "public"."provider_services" TO "service_role";



GRANT ALL ON TABLE "public"."security_events" TO "anon";
GRANT ALL ON TABLE "public"."security_events" TO "authenticated";
GRANT ALL ON TABLE "public"."security_events" TO "service_role";



GRANT ALL ON TABLE "public"."service_mappings" TO "anon";
GRANT ALL ON TABLE "public"."service_mappings" TO "authenticated";
GRANT ALL ON TABLE "public"."service_mappings" TO "service_role";



GRANT ALL ON TABLE "public"."wallet_transactions" TO "anon";
GRANT ALL ON TABLE "public"."wallet_transactions" TO "authenticated";
GRANT ALL ON TABLE "public"."wallet_transactions" TO "service_role";









ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON SEQUENCES TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON SEQUENCES TO "anon";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON SEQUENCES TO "authenticated";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON SEQUENCES TO "service_role";






ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON FUNCTIONS TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON FUNCTIONS TO "anon";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON FUNCTIONS TO "authenticated";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON FUNCTIONS TO "service_role";






ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON TABLES TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON TABLES TO "anon";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON TABLES TO "authenticated";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON TABLES TO "service_role";



































