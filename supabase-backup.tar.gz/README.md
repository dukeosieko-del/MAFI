# janjez.social - Supabase Database Backup

Generated: 2026-11-14T22:40:00Z
Project: rousjavuooduvicaobuv
Repository: https://github.com/dukeosieko-del/MAFI
Branch: database-backup

## Contents

| Directory | Description |
|---|---|
| `schema/database_schema.sql` | Full database schema (27 tables, functions, extensions, RLS policies) |
| `data/database_data.sql` | All data records from all tables (INSERT statements) |
| `migrations/` | All Supabase migration SQL files (35 migrations) |
| `logs/` | Placeholder for application logs (empty - logs streamed to Vercel) |

## Tables (27)

admin_activity_logs, affiliate_earnings, affiliate_referrals, affiliate_withdrawals,
blog_categories, blog_comments, blog_post_tags, blog_post_views, blog_posts,
blog_ratings, blog_tags, contact_messages, drip_feed_settings, email_verifications,
fulfillment_logs, janjez_services, notifications, orders, password_reset_tokens,
platform_settings, profiles, provider_services, security_events, service_mappings,
wallet_transactions

## Key Extensions

- pg_crypto (password hashing)
- pg_cron (scheduled jobs)
- pg_stat_statements (query performance)
- uuid-ossp (UUID generation)

## Key Functions

- credit_wallet(p_user_id, p_amount) - atomic wallet credit
- debit_wallet(p_user_id, p_amount) - atomic wallet debit with balance check

## Restoration

```bash
# 1. Restore schema
psql -d your_database -f schema/database_schema.sql

# 2. Restore data
psql -d your_database -f data/database_data.sql
```

## Notes

- Data dump was performed with `supabase db dump --data-only`
- Circular foreign-key constraints exist on `blog_comments` table; use `--disable-triggers` if restoring data-only dump fails
- Schema includes Row Level Security (RLS) policies
- The `wallet_transactions` table uses atomic RPC functions for credit/debit operations

## Application Context

This database supports janjez.social - a Kenya-based SMM panel accepting M-Pesa payments.
- Orders can be placed anonymously or by authenticated users
- Wallet system for deposits and order payments
- Brevo SMTP for transactional emails (verification, password reset, order notifications)
- Google OAuth and email/password authentication
- Admin panel for order fulfillment and user management